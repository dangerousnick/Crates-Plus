package plus.crates.Utils;

public class Constants {
    public static final String METADATA_KEY = "CratesPlus.Crate";
}
